package com.microegg.model;

public class Colling extends Product{
}
