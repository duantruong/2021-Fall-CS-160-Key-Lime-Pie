package com.microegg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroeggApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroeggApplication.class, args);
	}

}
